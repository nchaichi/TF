CATV <- read.csv("data-raw/GrowthCATV.csv")

save(CATV, file = "data/CATV.RData")
